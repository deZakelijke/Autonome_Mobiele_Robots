function url = get_camera_url()
url = 'http://145.18.169.162:8080//shot.jpg';